const express = require('express')
const app = express()
const { engine } = require('express-handlebars')
const path = require('path')
const bodyparser = require('body-parser')

app.use(bodyparser.urlencoded({ extended: false }))
app.set('view engine', 'handlebars')
app.engine('handlebars', engine(''))


app.use('/css', express.static(path.join(__dirname, 'node_modules/bootstrap/dist/css')))
app.use('/js', express.static(path.join(__dirname, 'node_modules/bootstrap/dist/js')))
app.use('/js', express.static(path.join(__dirname, 'node_modules/jquery/dist')))
app.use('/public', express.static(path.join(__dirname, 'public')))
app.use(express.static('fotos2'))

const fakedata = [
  {
    id: 1,
    nome: 'Palaye Royale',
    gravadora: 'Sumerian Records',
    genero: 'glam-rock',
    integrantes: '3',
    inicio: '2008',
    nacionalidade: 'Canadian-American',
    telefone: '+122 749890921'
  },
  {
    id: 2,
    nome: 'Luna Di',
    gravadora: 'Independente',
    genero: 'pop-rock',
    integrantes: '1',
    inicio: '2020',
    nacionalidade: 'Brazilian',
    telefone: '4002-8922'
  }

]

app.get('/', function (req, res) {
  //res.send('<h1>Eu não acredito</h1>')
  res.render('index')
})

app.get('/clientes', function (req, res) {
  res.render('cliente/cliente',
    { listaclientes: fakedata })
})

app.get('/clientes/novo', function (req, res) {
  res.render('cliente/formcliente')
})

app.post('/clientes/save', function (req, res) {

  let clienteantigo =
    fakedata.find(o => o.id == req.body.id)

  if (clienteantigo != undefined) {
    clienteantigo.nome = req.body.nome
    clienteantigo.gravadora = req.body.gravadora
    clienteantigo.genero = req.body.genero
    clienteantigo.integrantes = req.body.integrantes
    clienteantigo.inicio = req.body.inicio
    clienteantigo.nacionalidade = req.body.nacionalidade
    clienteantigo.telefone = req.body.telefone

  } else {
    let maiorId = 0
    
    if (fakedata.length > 0) {
      maiorId = Math.max(...fakedata.map(o => o.id))
    }
    
    
    // let maiorId = Math.max(...fakedata.map(o => o.id))

    let novoCliente = {
      id: maiorId + 1,
      nome: req.body.nome,
      gravadora: req.body.gravadora,
      genero: req.body.genero,
      integrantes: req.body.integrantes,
      inicio: req.body.inicio,
      nacionalidade: req.body.nacionalidade,
      telefone: req.body.telefone
    }
    fakedata.push(novoCliente)

  }
  res.redirect('/clientes')

})

app.get('/clientes/alterar/:id', function (req, res) {
  let id = req.params['id']

  let umcliente = fakedata.find(o => o.id == id)

  res.render('cliente/formcliente', { cliente: umcliente })
})

app.get('/clientes/delete/:id', function (req, res) {
  let cliente = fakedata.find(o => o.id == req.params['id'])

  let posicaocliente = fakedata.indexOf(cliente)

  if (posicaocliente > -1) {
    fakedata.splice(posicaocliente, 1)
  }
  res.redirect('/clientes')
})


app.listen(80, () => {
  console.log('Servidor rodando...')
  console.log('http://localhost/')
})